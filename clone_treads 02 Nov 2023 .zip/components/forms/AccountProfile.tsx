/** @format */

"use client";

const AccountProfile = () => {
  return <div>Account Profile</div>;
};
export default AccountProfile;
