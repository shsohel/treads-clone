/** @format */

function LeftSidebar() {
  return <h1>LeftSidebar</h1>;
}

export default LeftSidebar;
