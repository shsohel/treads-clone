/** @format */

function RightSidebar() {
  return <h1>RightSidebar</h1>;
}

export default RightSidebar;
