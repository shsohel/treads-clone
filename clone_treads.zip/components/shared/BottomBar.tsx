/** @format */

function BottomBar() {
  return <h1>BottomBar</h1>;
}

export default BottomBar;
