/** @format */
export default function Home() {
  return (
    <>
      <h2 className="head-text  text-left">Home</h2>
    </>
  );
}
