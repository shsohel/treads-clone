/** @format */

async function Page() {
  return (
    <main>
      <h1>On Boarding</h1>
    </main>
  );
}

export default Page;
